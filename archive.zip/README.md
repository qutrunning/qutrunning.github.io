QUT Running web site

Needs no database.

Local libraries:
Bootstrap
jQuery

Remote libraries and apps:
Google API for maps
Strava widget

